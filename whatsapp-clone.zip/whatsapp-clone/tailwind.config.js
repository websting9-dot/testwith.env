/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./app/**/*.{js,jsx,ts,tsx}", "./components/**/*.{js,jsx,ts,tsx}"],
  presets: [require("nativewind/preset")],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: "#075E54",
          dark: "#054C44",
          light: "#128C7E",
        },
        secondary: {
          DEFAULT: "#25D366",
          dark: "#1DA851",
        },
        chat: {
          bg: "#ECE5DD",
          bubble: "#DCF8C6",
          bubbleOther: "#FFFFFF",
        },
      },
    },
  },
  plugins: [],
};
