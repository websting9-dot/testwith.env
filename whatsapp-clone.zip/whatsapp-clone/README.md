# WhatsApp Clone

A full cross-platform chat app (iOS, Android, Web) built with **Expo + React Native + Supabase**.

## Features

- Email/password authentication
- Real-time messaging
- Chat list with last message preview
- Message status (sent / delivered / read)
- Profile & settings
- Dark-mode ready colors
- Works on iOS, Android and Web from one codebase

## Quick Start

### 1. Prerequisites

- Node.js 18+
- Expo Go app on your phone (or iOS Simulator / Android Emulator)
- Free Supabase account → https://supabase.com

### 2. Create Supabase project

1. Go to [supabase.com](https://supabase.com) and create a new project
2. Wait for it to finish setting up
3. Go to **SQL Editor** → New query
4. Paste the entire content of `supabase-schema.sql` and run it
5. Go to **Settings → API** and copy:
   - Project URL
   - `anon` public key

### 3. Configure the app

Create a file called `.env` in the project root:

```env
EXPO_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
EXPO_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
```

Also update `lib/supabase.ts` if you prefer hardcoding the values temporarily.

### 4. Install & run

```bash
cd whatsapp-clone
npm install
npx expo start --tunnel
```

**Important:** Use `--tunnel` so your phone does **not** need to be on the same Wi-Fi as your computer. It works from anywhere (mobile data, different network, etc.).

Then:

- Scan the QR code with **Expo Go** on your phone
- Press `w` for Web browser
- Press `i` for iOS Simulator (Mac only)
- Press `a` for Android Emulator

### 5. Test the app

1. Register two accounts (use two different browsers or devices)
2. In Supabase Table Editor, create a chat and add both users as participants (or use the `create_direct_chat` function)
3. Start messaging — messages appear in real time

## Project Structure

```
whatsapp-clone/
├── app/
│   ├── (auth)/          # Login & Register screens
│   ├── (tabs)/          # Chats, Status, Calls, Settings
│   ├── chat/[id].tsx    # Individual chat screen
│   ├── _layout.tsx
│   └── index.tsx
├── components/          # Reusable UI components
├── hooks/               # useAuth etc.
├── lib/                 # Supabase client
├── types/               # TypeScript types
├── supabase-schema.sql  # Database setup
└── ...
```

## Next Steps / Improvements

- [ ] Contact list & “New Chat” screen
- [ ] Image / file sharing (expo-image-picker + Supabase Storage)
- [ ] Push notifications (Expo Notifications)
- [ ] Online / last-seen status
- [ ] Group chat creation UI
- [ ] Message reactions & replies
- [ ] Voice messages
- [ ] End-to-end encryption (optional advanced feature)

## Tech Stack

- **Expo SDK 52** + Expo Router
- **React Native** + NativeWind (Tailwind)
- **Supabase** (Auth + Postgres + Realtime)
- TypeScript

---

Built with ❤️ using Expo & Supabase
