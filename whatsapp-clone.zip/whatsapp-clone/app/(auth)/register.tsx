import { useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
  Alert,
  ActivityIndicator,
} from "react-native";
import { Link, router } from "expo-router";
import { supabase } from "@/lib/supabase";

export default function Register() {
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleRegister() {
    if (!fullName || !email || !password) {
      Alert.alert("Error", "Please fill in all fields");
      return;
    }

    if (password.length < 6) {
      Alert.alert("Error", "Password must be at least 6 characters");
      return;
    }

    setLoading(true);

    const { data, error } = await supabase.auth.signUp({
      email: email.trim(),
      password,
      options: {
        data: {
          full_name: fullName.trim(),
        },
      },
    });

    if (error) {
      setLoading(false);
      Alert.alert("Registration failed", error.message);
      return;
    }

    // Create profile
    if (data.user) {
      const { error: profileError } = await supabase.from("profiles").insert({
        id: data.user.id,
        username: email.split("@")[0],
        full_name: fullName.trim(),
        status: "Hey there! I am using WhatsApp Clone",
      });

      if (profileError) {
        console.log("Profile creation error:", profileError);
      }
    }

    setLoading(false);
    Alert.alert("Success", "Account created! Please sign in.", [
      { text: "OK", onPress: () => router.replace("/(auth)/login") },
    ]);
  }

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      className="flex-1 bg-primary"
    >
      <View className="flex-1 justify-center px-8">
        <Text className="text-white text-4xl font-bold text-center mb-2">
          Create Account
        </Text>
        <Text className="text-white/80 text-center mb-10">
          Join WhatsApp Clone
        </Text>

        <View className="bg-white rounded-2xl p-6 shadow-lg">
          <Text className="text-gray-600 mb-1 font-medium">Full Name</Text>
          <TextInput
            className="border border-gray-200 rounded-xl px-4 py-3 mb-4 text-base"
            placeholder="John Doe"
            value={fullName}
            onChangeText={setFullName}
            autoCapitalize="words"
          />

          <Text className="text-gray-600 mb-1 font-medium">Email</Text>
          <TextInput
            className="border border-gray-200 rounded-xl px-4 py-3 mb-4 text-base"
            placeholder="you@example.com"
            value={email}
            onChangeText={setEmail}
            autoCapitalize="none"
            keyboardType="email-address"
          />

          <Text className="text-gray-600 mb-1 font-medium">Password</Text>
          <TextInput
            className="border border-gray-200 rounded-xl px-4 py-3 mb-6 text-base"
            placeholder="••••••••"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
          />

          <TouchableOpacity
            className="bg-secondary rounded-xl py-4 items-center"
            onPress={handleRegister}
            disabled={loading}
          >
            {loading ? (
              <ActivityIndicator color="white" />
            ) : (
              <Text className="text-white font-bold text-lg">Sign Up</Text>
            )}
          </TouchableOpacity>

          <View className="flex-row justify-center mt-6">
            <Text className="text-gray-500">Already have an account? </Text>
            <Link href="/(auth)/login" asChild>
              <TouchableOpacity>
                <Text className="text-primary font-bold">Sign In</Text>
              </TouchableOpacity>
            </Link>
          </View>
        </View>
      </View>
    </KeyboardAvoidingView>
  );
}
