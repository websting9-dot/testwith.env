import { useEffect, useState, useCallback } from "react";
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  Image,
  RefreshControl,
  ActivityIndicator,
} from "react-native";
import { router, useFocusEffect } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { supabase } from "@/lib/supabase";
import { useAuth } from "@/hooks/useAuth";
import { Chat } from "@/types";

export default function ChatsScreen() {
  const { user } = useAuth();
  const [chats, setChats] = useState<Chat[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const fetchChats = async () => {
    if (!user) return;

    // Get all chats the user participates in + participants + last message
    const { data, error } = await supabase
      .from("chat_participants")
      .select(
        `
        chat_id,
        chats (
          id,
          name,
          is_group,
          avatar_url,
          created_at
        )
      `
      )
      .eq("user_id", user.id);

    if (error) {
      console.log("Error fetching chats:", error);
      setLoading(false);
      setRefreshing(false);
      return;
    }

    const chatList: Chat[] = [];

    for (const item of data || []) {
      const chat = (item as any).chats;
      if (!chat) continue;

      // Last message
      const { data: messages } = await supabase
        .from("messages")
        .select("*")
        .eq("chat_id", chat.id)
        .order("created_at", { ascending: false })
        .limit(1);

      // For 1:1 chats, get the other participant's profile for name + avatar
      let displayName = chat.name || "Chat";
      let displayAvatar = chat.avatar_url;

      if (!chat.is_group) {
        const { data: participants } = await supabase
          .from("chat_participants")
          .select(
            `
            user_id,
            profiles (
              id,
              full_name,
              username,
              avatar_url
            )
          `
          )
          .eq("chat_id", chat.id)
          .neq("user_id", user.id)
          .limit(1);

        const other = (participants?.[0] as any)?.profiles;
        if (other) {
          displayName = other.full_name || other.username || "Unknown";
          displayAvatar = other.avatar_url || null;
        }
      }

      chatList.push({
        ...chat,
        name: displayName,
        avatar_url: displayAvatar,
        last_message: messages?.[0] || null,
      });
    }

    // Sort by last message time
    chatList.sort((a, b) => {
      const aTime = a.last_message?.created_at || a.created_at;
      const bTime = b.last_message?.created_at || b.created_at;
      return new Date(bTime).getTime() - new Date(aTime).getTime();
    });

    setChats(chatList);
    setLoading(false);
    setRefreshing(false);
  };

  useFocusEffect(
    useCallback(() => {
      fetchChats();
    }, [user])
  );

  // Realtime subscription for new messages
  useEffect(() => {
    if (!user) return;

    const channel = supabase
      .channel("chats-updates")
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "messages" },
        () => {
          fetchChats();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user]);

  const onRefresh = () => {
    setRefreshing(true);
    fetchChats();
  };

  const formatTime = (dateStr: string) => {
    const date = new Date(dateStr);
    const now = new Date();
    const isToday = date.toDateString() === now.toDateString();
    if (isToday) {
      return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    }
    return date.toLocaleDateString([], { month: "short", day: "numeric" });
  };

  if (loading) {
    return (
      <View className="flex-1 items-center justify-center bg-white">
        <ActivityIndicator size="large" color="#075E54" />
      </View>
    );
  }

  return (
    <View className="flex-1 bg-white">
      <FlatList
        data={chats}
        keyExtractor={(item) => item.id}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
        ListEmptyComponent={
          <View className="flex-1 items-center justify-center py-20">
            <Ionicons name="chatbubbles-outline" size={64} color="#ccc" />
            <Text className="text-gray-400 mt-4 text-lg">No chats yet</Text>
            <Text className="text-gray-400 mt-1">Start a new conversation</Text>
          </View>
        }
        renderItem={({ item }) => (
          <TouchableOpacity
            className="flex-row items-center px-4 py-3 border-b border-gray-100"
            onPress={() => router.push(`/chat/${item.id}`)}
            activeOpacity={0.7}
          >
            <View className="w-14 h-14 rounded-full bg-primary/15 items-center justify-center mr-3 overflow-hidden">
              {item.avatar_url ? (
                <Image
                  source={{ uri: item.avatar_url }}
                  className="w-14 h-14"
                />
              ) : item.is_group ? (
                <Ionicons name="people" size={28} color="#075E54" />
              ) : (
                <Text className="text-primary font-bold text-xl">
                  {(item.name || "?")[0].toUpperCase()}
                </Text>
              )}
            </View>

            <View className="flex-1">
              <View className="flex-row justify-between items-center">
                <Text className="text-base font-semibold text-gray-900" numberOfLines={1}>
                  {item.name || "Chat"}
                </Text>
                {item.last_message && (
                  <Text className="text-xs text-gray-400">
                    {formatTime(item.last_message.created_at)}
                  </Text>
                )}
              </View>
              <Text className="text-sm text-gray-500 mt-0.5" numberOfLines={1}>
                {item.last_message?.content || "No messages yet"}
              </Text>
            </View>
          </TouchableOpacity>
        )}
      />

      {/* Floating Action Button */}
      <TouchableOpacity
        className="absolute bottom-6 right-6 w-14 h-14 bg-secondary rounded-full items-center justify-center shadow-lg"
        onPress={() => router.push("/new-chat")}
        activeOpacity={0.8}
      >
        <Ionicons name="chatbubble" size={24} color="white" />
      </TouchableOpacity>
    </View>
  );
}
