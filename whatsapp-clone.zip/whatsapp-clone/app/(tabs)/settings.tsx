import { View, Text, TouchableOpacity, Alert } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import { supabase } from "@/lib/supabase";
import { useAuth } from "@/hooks/useAuth";

export default function SettingsScreen() {
  const { user } = useAuth();

  async function handleLogout() {
    Alert.alert("Log out", "Are you sure you want to log out?", [
      { text: "Cancel", style: "cancel" },
      {
        text: "Log out",
        style: "destructive",
        onPress: async () => {
          await supabase.auth.signOut();
          router.replace("/(auth)/login");
        },
      },
    ]);
  }

  return (
    <View className="flex-1 bg-gray-50">
      <View className="bg-white mt-4">
        <View className="flex-row items-center px-4 py-4 border-b border-gray-100">
          <View className="w-16 h-16 rounded-full bg-primary items-center justify-center mr-4">
            <Ionicons name="person" size={32} color="white" />
          </View>
          <View>
            <Text className="text-lg font-semibold text-gray-900">
              {user?.user_metadata?.full_name || "User"}
            </Text>
            <Text className="text-gray-500">{user?.email}</Text>
          </View>
        </View>

        <TouchableOpacity className="flex-row items-center px-4 py-4 border-b border-gray-100">
          <Ionicons name="key-outline" size={22} color="#075E54" />
          <Text className="ml-4 text-base text-gray-800">Account</Text>
        </TouchableOpacity>

        <TouchableOpacity className="flex-row items-center px-4 py-4 border-b border-gray-100">
          <Ionicons name="lock-closed-outline" size={22} color="#075E54" />
          <Text className="ml-4 text-base text-gray-800">Privacy</Text>
        </TouchableOpacity>

        <TouchableOpacity className="flex-row items-center px-4 py-4 border-b border-gray-100">
          <Ionicons name="notifications-outline" size={22} color="#075E54" />
          <Text className="ml-4 text-base text-gray-800">Notifications</Text>
        </TouchableOpacity>

        <TouchableOpacity className="flex-row items-center px-4 py-4 border-b border-gray-100">
          <Ionicons name="color-palette-outline" size={22} color="#075E54" />
          <Text className="ml-4 text-base text-gray-800">Chat Wallpaper</Text>
        </TouchableOpacity>
      </View>

      <TouchableOpacity
        className="bg-white mt-6 flex-row items-center px-4 py-4"
        onPress={handleLogout}
      >
        <Ionicons name="log-out-outline" size={22} color="#FF3B30" />
        <Text className="ml-4 text-base text-red-500 font-medium">Log out</Text>
      </TouchableOpacity>
    </View>
  );
}
