export type Profile = {
  id: string;
  username: string;
  full_name: string | null;
  avatar_url: string | null;
  status: string | null;
  last_seen: string | null;
  created_at: string;
};

export type Chat = {
  id: string;
  name: string | null;
  is_group: boolean;
  avatar_url: string | null;
  created_at: string;
  last_message?: Message | null;
  participants?: Profile[];
};

export type Message = {
  id: string;
  chat_id: string;
  sender_id: string;
  content: string;
  type: "text" | "image" | "file";
  media_url: string | null;
  created_at: string;
  status: "sent" | "delivered" | "read";
  sender?: Profile;
};

export type ChatParticipant = {
  chat_id: string;
  user_id: string;
  joined_at: string;
};
