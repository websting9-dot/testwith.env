import { useEffect, useState, useRef, useCallback } from "react";
import {
  View,
  Text,
  FlatList,
  TextInput,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
} from "react-native";
import { useLocalSearchParams, Stack, router } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { supabase } from "@/lib/supabase";
import { useAuth } from "@/hooks/useAuth";
import { Message } from "@/types";

export default function ChatScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { user } = useAuth();
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [chatName, setChatName] = useState("Chat");
  const flatListRef = useRef<FlatList>(null);

  const fetchMessages = useCallback(async () => {
    if (!id) return;

    const { data, error } = await supabase
      .from("messages")
      .select(`
        *,
        sender:profiles(id, full_name, avatar_url)
      `)
      .eq("chat_id", id)
      .order("created_at", { ascending: true });

    if (error) {
      console.log("Error fetching messages:", error);
    } else {
      setMessages(data || []);
    }
    setLoading(false);
  }, [id]);

  const fetchChatInfo = async () => {
    if (!id || !user) return;

    const { data: chat } = await supabase
      .from("chats")
      .select("name, is_group")
      .eq("id", id)
      .single();

    if (!chat) return;

    // For group chats use the group name
    if (chat.is_group) {
      setChatName(chat.name || "Group");
      return;
    }

    // For 1:1 chats show the other person's current name
    const { data: participants } = await supabase
      .from("chat_participants")
      .select(
        `
        user_id,
        profiles (
          full_name,
          username
        )
      `
      )
      .eq("chat_id", id)
      .neq("user_id", user.id)
      .limit(1);

    const other = (participants?.[0] as any)?.profiles;
    if (other) {
      setChatName(other.full_name || other.username || "Chat");
    } else {
      setChatName(chat.name || "Chat");
    }
  };

  useEffect(() => {
    fetchMessages();
    fetchChatInfo();
  }, [id, user]);

  // Realtime subscription
  useEffect(() => {
    if (!id) return;

    const channel = supabase
      .channel(`chat-${id}`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "messages",
          filter: `chat_id=eq.${id}`,
        },
        (payload) => {
          const newMsg = payload.new as Message;
          setMessages((prev) => {
            // Avoid duplicates
            if (prev.some((m) => m.id === newMsg.id)) return prev;
            return [...prev, newMsg];
          });
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [id]);

  const sendMessage = async () => {
    if (!newMessage.trim() || !user || !id || sending) return;

    setSending(true);
    const content = newMessage.trim();
    setNewMessage("");

    const { error } = await supabase.from("messages").insert({
      chat_id: id,
      sender_id: user.id,
      content,
      type: "text",
      status: "sent",
    });

    if (error) {
      console.log("Send error:", error);
      setNewMessage(content); // restore
    }

    setSending(false);
  };

  const formatTime = (dateStr: string) => {
    return new Date(dateStr).toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const renderMessage = ({ item }: { item: Message }) => {
    const isMine = item.sender_id === user?.id;

    return (
      <View
        className={`mb-2 max-w-[80%] ${isMine ? "self-end" : "self-start"}`}
      >
        <View
          className={`rounded-2xl px-4 py-2 ${
            isMine ? "bg-chat-bubble rounded-br-sm" : "bg-white rounded-bl-sm"
          }`}
          style={{
            shadowColor: "#000",
            shadowOffset: { width: 0, height: 1 },
            shadowOpacity: 0.1,
            shadowRadius: 1,
            elevation: 1,
          }}
        >
          {!isMine && item.sender && (
            <Text className="text-xs text-primary font-semibold mb-0.5">
              {(item.sender as any).full_name}
            </Text>
          )}
          <Text className="text-base text-gray-900">{item.content}</Text>
          <View className="flex-row items-center justify-end mt-1">
            <Text className="text-[10px] text-gray-500 mr-1">
              {formatTime(item.created_at)}
            </Text>
            {isMine && (
              <Ionicons
                name={item.status === "read" ? "checkmark-done" : "checkmark"}
                size={14}
                color={item.status === "read" ? "#34B7F1" : "#999"}
              />
            )}
          </View>
        </View>
      </View>
    );
  };

  return (
    <>
      <Stack.Screen
        options={{
          title: chatName,
          headerStyle: { backgroundColor: "#075E54" },
          headerTintColor: "#fff",
          headerBackTitle: "Back",
        }}
      />

      <KeyboardAvoidingView
        className="flex-1"
        behavior={Platform.OS === "ios" ? "padding" : undefined}
        keyboardVerticalOffset={Platform.OS === "ios" ? 90 : 0}
      >
        <View className="flex-1 bg-chat-bg">
          {loading ? (
            <View className="flex-1 items-center justify-center">
              <ActivityIndicator size="large" color="#075E54" />
            </View>
          ) : (
            <FlatList
              ref={flatListRef}
              data={messages}
              keyExtractor={(item) => item.id}
              renderItem={renderMessage}
              contentContainerStyle={{ padding: 12, paddingBottom: 8 }}
              onContentSizeChange={() =>
                flatListRef.current?.scrollToEnd({ animated: false })
              }
              ListEmptyComponent={
                <View className="items-center py-20">
                  <Text className="text-gray-500">
                    No messages yet. Say hello!
                  </Text>
                </View>
              }
            />
          )}

          {/* Input bar */}
          <View className="flex-row items-end px-2 py-2 bg-white border-t border-gray-200">
            <TouchableOpacity className="p-2">
              <Ionicons name="happy-outline" size={24} color="#075E54" />
            </TouchableOpacity>

            <View className="flex-1 bg-gray-100 rounded-full px-4 py-2 mx-1 max-h-28">
              <TextInput
                className="text-base text-gray-900"
                placeholder="Message"
                value={newMessage}
                onChangeText={setNewMessage}
                multiline
                maxLength={2000}
              />
            </View>

            <TouchableOpacity className="p-2">
              <Ionicons name="attach" size={24} color="#075E54" />
            </TouchableOpacity>

            <TouchableOpacity
              className="w-11 h-11 bg-secondary rounded-full items-center justify-center ml-1"
              onPress={sendMessage}
              disabled={sending || !newMessage.trim()}
            >
              {sending ? (
                <ActivityIndicator size="small" color="white" />
              ) : (
                <Ionicons name="send" size={20} color="white" />
              )}
            </TouchableOpacity>
          </View>
        </View>
      </KeyboardAvoidingView>
    </>
  );
}
