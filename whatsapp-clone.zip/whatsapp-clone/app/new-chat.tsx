import { useEffect, useState, useCallback } from "react";
import {
  View,
  Text,
  FlatList,
  TextInput,
  TouchableOpacity,
  Image,
  ActivityIndicator,
  Alert,
} from "react-native";
import { Stack, router } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { supabase } from "@/lib/supabase";
import { useAuth } from "@/hooks/useAuth";
import { Profile } from "@/types";

export default function NewChatScreen() {
  const { user } = useAuth();
  const [contacts, setContacts] = useState<Profile[]>([]);
  const [filtered, setFiltered] = useState<Profile[]>([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState<string | null>(null);

  const fetchContacts = useCallback(async () => {
    if (!user) return;

    const { data, error } = await supabase
      .from("profiles")
      .select("*")
      .neq("id", user.id)
      .order("full_name", { ascending: true });

    if (error) {
      console.log("Error fetching contacts:", error);
      Alert.alert("Error", "Could not load contacts");
    } else {
      setContacts(data || []);
      setFiltered(data || []);
    }
    setLoading(false);
  }, [user]);

  useEffect(() => {
    fetchContacts();
  }, [fetchContacts]);

  useEffect(() => {
    if (!search.trim()) {
      setFiltered(contacts);
      return;
    }
    const q = search.toLowerCase();
    setFiltered(
      contacts.filter(
        (c) =>
          c.full_name?.toLowerCase().includes(q) ||
          c.username?.toLowerCase().includes(q) ||
          c.status?.toLowerCase().includes(q)
      )
    );
  }, [search, contacts]);

  const startChat = async (contact: Profile) => {
    if (!user || creating) return;

    setCreating(contact.id);

    try {
      // Call the Postgres function to create or get existing direct chat
      const { data, error } = await supabase.rpc("create_direct_chat", {
        other_user_id: contact.id,
      });

      if (error) {
        console.log("Create chat error:", error);
        Alert.alert("Error", error.message || "Could not start chat");
        setCreating(null);
        return;
      }

      const chatId = data as string;
      router.replace(`/chat/${chatId}`);
    } catch (err) {
      console.log(err);
      Alert.alert("Error", "Something went wrong");
      setCreating(null);
    }
  };

  const renderContact = ({ item }: { item: Profile }) => {
    const isCreating = creating === item.id;

    return (
      <TouchableOpacity
        className="flex-row items-center px-4 py-3 border-b border-gray-100 active:bg-gray-50"
        onPress={() => startChat(item)}
        disabled={!!creating}
      >
        <View className="w-12 h-12 rounded-full bg-primary/10 items-center justify-center mr-3 overflow-hidden">
          {item.avatar_url ? (
            <Image source={{ uri: item.avatar_url }} className="w-12 h-12" />
          ) : (
            <Text className="text-primary font-bold text-lg">
              {(item.full_name || item.username || "?")[0].toUpperCase()}
            </Text>
          )}
        </View>

        <View className="flex-1">
          <Text className="text-base font-semibold text-gray-900" numberOfLines={1}>
            {item.full_name || item.username || "Unknown"}
          </Text>
          <Text className="text-sm text-gray-500 mt-0.5" numberOfLines={1}>
            {item.status || "Hey there! I am using WhatsApp Clone"}
          </Text>
        </View>

        {isCreating && <ActivityIndicator size="small" color="#075E54" />}
      </TouchableOpacity>
    );
  };

  return (
    <>
      <Stack.Screen
        options={{
          title: "New Chat",
          headerStyle: { backgroundColor: "#075E54" },
          headerTintColor: "#fff",
          headerBackTitle: "Back",
        }}
      />

      <View className="flex-1 bg-white">
        {/* Search bar */}
        <View className="px-4 py-3 bg-gray-50 border-b border-gray-200">
          <View className="flex-row items-center bg-white rounded-xl px-3 py-2 border border-gray-200">
            <Ionicons name="search" size={20} color="#8E8E93" />
            <TextInput
              className="flex-1 ml-2 text-base text-gray-900"
              placeholder="Search name or username"
              value={search}
              onChangeText={setSearch}
              autoCapitalize="none"
              clearButtonMode="while-editing"
            />
            {search.length > 0 && (
              <TouchableOpacity onPress={() => setSearch("")}>
                <Ionicons name="close-circle" size={20} color="#8E8E93" />
              </TouchableOpacity>
            )}
          </View>
        </View>

        {/* New Group shortcut */}
        <TouchableOpacity
          className="flex-row items-center px-4 py-4 border-b border-gray-100"
          onPress={() => Alert.alert("Coming soon", "Group chats will be added next.")}
        >
          <View className="w-12 h-12 rounded-full bg-secondary items-center justify-center mr-3">
            <Ionicons name="people" size={24} color="white" />
          </View>
          <Text className="text-base font-semibold text-primary">New Group</Text>
        </TouchableOpacity>

        {/* Contacts header */}
        <View className="px-4 py-2 bg-gray-50">
          <Text className="text-xs font-semibold text-gray-500 uppercase tracking-wide">
            Contacts on WhatsApp Clone
          </Text>
        </View>

        {loading ? (
          <View className="flex-1 items-center justify-center">
            <ActivityIndicator size="large" color="#075E54" />
          </View>
        ) : (
          <FlatList
            data={filtered}
            keyExtractor={(item) => item.id}
            renderItem={renderContact}
            ListEmptyComponent={
              <View className="items-center py-16 px-8">
                <Ionicons name="people-outline" size={56} color="#ccc" />
                <Text className="text-gray-400 mt-4 text-center text-base">
                  {search
                    ? "No contacts match your search"
                    : "No other users yet.\nRegister another account to start chatting."}
                </Text>
              </View>
            }
          />
        )}
      </View>
    </>
  );
}
