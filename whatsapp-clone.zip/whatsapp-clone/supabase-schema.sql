-- WhatsApp Clone Database Schema for Supabase
-- Run this in the Supabase SQL Editor

-- Enable UUID extension
create extension if not exists "uuid-ossp";

-- Profiles table (extends auth.users)
create table public.profiles (
  id uuid references auth.users on delete cascade primary key,
  username text unique,
  full_name text,
  avatar_url text,
  status text default 'Hey there! I am using WhatsApp Clone',
  last_seen timestamptz default now(),
  created_at timestamptz default now()
);

-- Chats table
create table public.chats (
  id uuid default uuid_generate_v4() primary key,
  name text,
  is_group boolean default false,
  avatar_url text,
  created_by uuid references public.profiles(id),
  created_at timestamptz default now()
);

-- Chat participants
create table public.chat_participants (
  chat_id uuid references public.chats(id) on delete cascade,
  user_id uuid references public.profiles(id) on delete cascade,
  joined_at timestamptz default now(),
  primary key (chat_id, user_id)
);

-- Messages table
create table public.messages (
  id uuid default uuid_generate_v4() primary key,
  chat_id uuid references public.chats(id) on delete cascade not null,
  sender_id uuid references public.profiles(id) on delete set null,
  content text not null,
  type text default 'text' check (type in ('text', 'image', 'file')),
  media_url text,
  status text default 'sent' check (status in ('sent', 'delivered', 'read')),
  created_at timestamptz default now()
);

-- Indexes for performance
create index messages_chat_id_created_at_idx on public.messages(chat_id, created_at desc);
create index chat_participants_user_id_idx on public.chat_participants(user_id);

-- Enable Row Level Security
alter table public.profiles enable row level security;
alter table public.chats enable row level security;
alter table public.chat_participants enable row level security;
alter table public.messages enable row level security;

-- Profiles policies
create policy "Public profiles are viewable by everyone"
  on public.profiles for select using (true);

create policy "Users can update own profile"
  on public.profiles for update using (auth.uid() = id);

create policy "Users can insert own profile"
  on public.profiles for insert with check (auth.uid() = id);

-- Chats policies
create policy "Users can view chats they participate in"
  on public.chats for select using (
    exists (
      select 1 from public.chat_participants
      where chat_id = id and user_id = auth.uid()
    )
  );

create policy "Authenticated users can create chats"
  on public.chats for insert with check (auth.uid() = created_by);

-- Chat participants policies
create policy "Users can view participants of their chats"
  on public.chat_participants for select using (
    exists (
      select 1 from public.chat_participants cp
      where cp.chat_id = chat_id and cp.user_id = auth.uid()
    )
  );

create policy "Users can join chats"
  on public.chat_participants for insert with check (auth.uid() = user_id);

-- Messages policies
create policy "Users can view messages in their chats"
  on public.messages for select using (
    exists (
      select 1 from public.chat_participants
      where chat_id = messages.chat_id and user_id = auth.uid()
    )
  );

create policy "Users can send messages to their chats"
  on public.messages for insert with check (
    auth.uid() = sender_id and
    exists (
      select 1 from public.chat_participants
      where chat_id = messages.chat_id and user_id = auth.uid()
    )
  );

-- Enable Realtime for messages
alter publication supabase_realtime add table public.messages;

-- Function to create a direct chat between two users
create or replace function create_direct_chat(other_user_id uuid)
returns uuid
language plpgsql
security definer
as $$
declare
  existing_chat_id uuid;
  new_chat_id uuid;
  other_user_name text;
begin
  -- Check if a direct chat already exists
  select c.id into existing_chat_id
  from public.chats c
  join public.chat_participants cp1 on cp1.chat_id = c.id and cp1.user_id = auth.uid()
  join public.chat_participants cp2 on cp2.chat_id = c.id and cp2.user_id = other_user_id
  where c.is_group = false
  limit 1;

  if existing_chat_id is not null then
    return existing_chat_id;
  end if;

  -- Get other user's name
  select full_name into other_user_name from public.profiles where id = other_user_id;

  -- Create new chat
  insert into public.chats (name, is_group, created_by)
  values (other_user_name, false, auth.uid())
  returning id into new_chat_id;

  -- Add both participants
  insert into public.chat_participants (chat_id, user_id) values
    (new_chat_id, auth.uid()),
    (new_chat_id, other_user_id);

  return new_chat_id;
end;
$$;
