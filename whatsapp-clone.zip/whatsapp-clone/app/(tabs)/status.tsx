import { View, Text } from "react-native";
import { Ionicons } from "@expo/vector-icons";

export default function StatusScreen() {
  return (
    <View className="flex-1 items-center justify-center bg-white">
      <Ionicons name="radio-button-on" size={64} color="#ccc" />
      <Text className="text-gray-400 mt-4 text-lg">Status</Text>
      <Text className="text-gray-400 mt-1">Coming soon</Text>
    </View>
  );
}
